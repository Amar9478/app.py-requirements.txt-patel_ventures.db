import streamlit as st
import sqlite3
import datetime
import calendar
import io
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

# Page Config
st.set_page_config(
    page_title="Patel Ventures Inc. - Financial Register",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for dark luxury restaurant & finance theme
st.markdown("""
<style>
    .main { background-color: #0f172a; }
    .stMetric {
        background-color: #1e293b;
        border: 1px solid #334155;
        border-radius: 10px;
        padding: 12px 16px;
    }
    div[data-testid="stMetricValue"] {
        font-size: 1.6rem;
        font-weight: 700;
    }
    .header-box {
        background: linear-gradient(90deg, #1e293b 0%, #0f172a 100%);
        border: 1px solid #334155;
        padding: 16px 20px;
        border-radius: 12px;
        margin-bottom: 20px;
    }
</style>
""", unsafe_allow_html=True)

DB_PATH = "patel_ventures.db"

EXPENSE_CATEGORIES = [
    "SALARY", "RENT", "LIGHT BILL", "MORTGAGE", "GROCERY", "MEAT", "BEKARY",
    "ACCOUNTANT", "MISSALANIOUS", "INTERNET BILL", "PHONE BILL", "PEPSICO",
    "TAXES GST AND ETC.", "SIGN RENTAL", "WCB", "SNAPEY POS", "PEST CONTROL",
    "BANK DEPOSIT", "COMMISION", "ARPITBHAI", "UTILITIES", "OTHER"
]

def get_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS daily_sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            month_year TEXT NOT NULL,
            entry_date TEXT NOT NULL,
            dinein REAL DEFAULT 0,
            pickup REAL DEFAULT 0,
            delivery REAL DEFAULT 0,
            tip REAL DEFAULT 0,
            total REAL DEFAULT 0,
            gst REAL DEFAULT 0,
            commission REAL DEFAULT 0,
            UNIQUE(month_year, entry_date)
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            month_year TEXT NOT NULL,
            entry_date TEXT,
            amount REAL NOT NULL,
            category TEXT NOT NULL,
            narration TEXT
        )
    """)
    conn.commit()
    return conn

conn = get_db()

# Sidebar: Month Selector & Creator
st.sidebar.title("🏢 Patel Ventures Inc.")
st.sidebar.caption("Monthly Financial Balance Sheet")

cur = conn.cursor()
cur.execute("SELECT DISTINCT month_year FROM daily_sales")
months = [r[0] for r in cur.fetchall()]

def month_sort_key(m_str):
    try:
        parts = m_str.strip().split()
        return (int(parts[1]), datetime.datetime.strptime(parts[0], "%B").month)
    except Exception:
        return (0, 0)

months.sort(key=month_sort_key, reverse=True)
if not months:
    months = ["MAY 2025"]

selected_month = st.sidebar.selectbox("📅 Select Month", months, index=0 if "MAY 2025" not in months else months.index("MAY 2025"))

# Create New Month Expander
with st.sidebar.expander("➕ Create New Month"):
    month_names = list(calendar.month_name)[1:]
    new_m = st.selectbox("Month", month_names, index=datetime.date.today().month - 1)
    new_y = st.number_input("Year", min_value=2024, max_value=2032, value=datetime.date.today().year)
    if st.button("Create Month", use_container_width=True):
        new_label = f"{new_m.upper()} {new_y}"
        m_month = month_names.index(new_m) + 1
        _, num_days = calendar.monthrange(int(new_y), m_month)
        
        c = conn.cursor()
        for d in range(1, num_days + 1):
            dt_str = f"{new_y:04d}-{m_month:02d}-{d:02d}"
            c.execute("""
                INSERT OR IGNORE INTO daily_sales (month_year, entry_date, dinein, pickup, delivery, tip, total, gst, commission)
                VALUES (?, ?, 0, 0, 0, 0, 0, 0, 0)
            """, (new_label, dt_str))
        conn.commit()
        st.success(f"Created {new_label}!")
        st.rerun()

# Header Banner
st.markdown(f"""
<div class="header-box">
    <h2 style="color: #f59e0b; margin: 0;">PATEL VENTURES INC.</h2>
    <p style="color: #94a3b8; margin: 0; font-size: 0.95rem;">Monthly Financial Operations & Balance Sheet — <b>{selected_month}</b></p>
</div>
""", unsafe_allow_html=True)

# Fetch Month Sales
cur.execute("""
    SELECT id, entry_date, dinein, pickup, delivery, tip, total, gst, commission
    FROM daily_sales WHERE month_year = ? ORDER BY entry_date ASC
""", (selected_month,))
sales_records = cur.fetchall()

# Fetch Month Expenses
cur.execute("""
    SELECT id, category, amount, narration FROM expenses
    WHERE month_year = ? ORDER BY id ASC
""", (selected_month,))
exp_records = cur.fetchall()

# Compute KPI Metrics
tot_sales = sum(r[6] for r in sales_records) if sales_records else 0.0
tot_dinein = sum(r[2] for r in sales_records) if sales_records else 0.0
tot_delivery = sum(r[4] for r in sales_records) if sales_records else 0.0
tot_gst = sum(r[7] for r in sales_records) if sales_records else 0.0
tot_comm = sum(r[8] for r in sales_records) if sales_records else 0.0
tot_exp = sum(r[2] for r in exp_records) if exp_records else 0.0
net_lumsum = tot_sales - tot_exp
num_days = len(sales_records) if sales_records else 30
avg_sale_day = (tot_sales / num_days) if num_days else 0.0

# Render KPIs
kpi1, kpi2, kpi3, kpi4 = st.columns(4)
kpi1.metric("Total Gross Sales", f"${tot_sales:,.2f}")
kpi2.metric("Total Expenses", f"${tot_exp:,.2f}", delta=f"-${tot_exp:,.2f}", delta_color="inverse")
kpi3.metric("Net Lumsum Earning", f"${net_lumsum:,.2f}", delta=f"{'+' if net_lumsum>=0 else ''}${net_lumsum:,.2f}")
kpi4.metric("Average Sale / Day", f"${avg_sale_day:,.2f}")

# Tabs: Daily Sales, Expenses, and Excel Export
tab_sales, tab_expenses, tab_export = st.tabs([
    "📅 Daily Income Register", 
    "💸 Expenses Ledger", 
    "📥 A4 Excel Export"
])

with tab_sales:
    st.subheader("Daily Sales Entry & Register")
    
    # Input Row for Fast Entry / Edit
    with st.expander("➕ Log / Update Day Sales", expanded=True):
        col_d, col_di, col_pu, col_del, col_tip, col_btn = st.columns([1.2, 1, 1, 1, 1, 1])
        
        # Available dates
        dates_in_month = [r[1] for r in sales_records]
        selected_date = col_d.selectbox("Select Date", dates_in_month if dates_in_month else [datetime.date.today().strftime("%Y-%m-%d")])
        
        # Prepopulate existing values if any
        existing_row = next((r for r in sales_records if r[1] == selected_date), None)
        init_di = existing_row[2] if existing_row else 0.0
        init_pu = existing_row[3] if existing_row else 0.0
        init_del = existing_row[4] if existing_row else 0.0
        init_tip = existing_row[5] if existing_row else 0.0
        
        in_dinein = col_di.number_input("Dine-In ($)", value=float(init_di), step=10.0, format="%.2f")
        in_pickup = col_pu.number_input("Pickup ($)", value=float(init_pu), step=10.0, format="%.2f")
        in_deliv = col_del.number_input("Delivery ($)", value=float(init_del), step=10.0, format="%.2f")
        in_tip = col_tip.number_input("Tips ($)", value=float(init_tip), step=5.0, format="%.2f")
        
        if col_btn.button("💾 Save Day", use_container_width=True):
            tot = in_dinein + in_pickup + in_deliv + in_tip
            gst_calc = round(tot * 0.05, 4)
            comm_calc = round(in_deliv * 0.30, 4)
            c = conn.cursor()
            c.execute("""
                INSERT OR REPLACE INTO daily_sales (month_year, entry_date, dinein, pickup, delivery, tip, total, gst, commission)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (selected_month, selected_date, in_dinein, in_pickup, in_deliv, in_tip, tot, gst_calc, comm_calc))
            conn.commit()
            st.success(f"Saved {selected_date}!")
            st.rerun()

    # Sales Table
    if sales_records:
        import pandas as pd
        df_sales = pd.DataFrame(sales_records, columns=["ID", "Date", "Dine-In ($)", "Pickup ($)", "Delivery ($)", "Tips ($)", "Total Sales ($)", "GST (5%)", "Commission (30%)"])
        # Format columns
        for c in ["Dine-In ($)", "Pickup ($)", "Delivery ($)", "Tips ($)", "Total Sales ($)", "GST (5%)", "Commission (30%)"]:
            df_sales[c] = df_sales[c].apply(lambda x: f"${x:,.2f}" if x else "-")
        st.dataframe(df_sales.drop(columns=["ID"]), use_container_width=True, hide_index=True)

with tab_expenses:
    st.subheader("Biweekly & Monthly Operating Expenses")
    
    with st.expander("➕ Add New Expense", expanded=True):
        ec1, ec2, ec3, ec4 = st.columns([1.5, 1.2, 2, 1])
        e_cat = ec1.selectbox("Category", EXPENSE_CATEGORIES)
        e_amt = ec2.number_input("Amount ($)", min_value=0.0, step=50.0, format="%.2f")
        e_narr = ec3.text_input("Narration / Comments", placeholder="e.g. Utility bill, Biweekly check")
        if ec4.button("Add Expense", use_container_width=True):
            if e_amt > 0:
                c = conn.cursor()
                c.execute("""
                    INSERT INTO expenses (month_year, entry_date, amount, category, narration)
                    VALUES (?, ?, ?, ?, ?)
                """, (selected_month, datetime.date.today().strftime("%Y-%m-%d"), e_amt, e_cat, e_narr))
                conn.commit()
                st.success("Expense added!")
                st.rerun()
            else:
                st.warning("Please enter an amount greater than 0.")
                
    if exp_records:
        import pandas as pd
        df_exp = pd.DataFrame(exp_records, columns=["ID", "Category", "Amount ($)", "Narration"])
        df_exp["Amount ($)"] = df_exp["Amount ($)"].apply(lambda x: f"${x:,.2f}")
        
        col_tbl, col_del = st.columns([3, 1])
        with col_tbl:
            st.dataframe(df_exp, use_container_width=True, hide_index=True)
        with col_del:
            st.markdown("##### Remove Expense")
            exp_to_del = st.selectbox("Select # ID to Delete", [r[0] for r in exp_records])
            if st.button("🗑️ Delete", type="primary", use_container_width=True):
                c = conn.cursor()
                c.execute("DELETE FROM expenses WHERE id = ?", (exp_to_del,))
                conn.commit()
                st.info(f"Deleted #{exp_to_del}")
                st.rerun()

with tab_export:
    st.subheader("Generate & Download Official Excel Sheet")
    st.write(f"Export formatted **{selected_month}** balance sheet matching `PATEL VEN.xlsx` with formulas and preset A4 printing.")
    
    def generate_excel():
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = selected_month[:31]
        
        yellow_hdr = PatternFill(start_color="FFFFFF00", end_color="FFFFFF00", fill_type="solid")
        total_fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
        exp_hdr_fill = PatternFill(start_color="002060", end_color="002060", fill_type="solid")
        lumsum_fill = PatternFill(start_color="E2EFDA", end_color="E2EFDA", fill_type="solid")
        font_bold = Font(name="Calibri", size=11, bold=True)
        font_white_bold = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
        font_main = Font(name="Calibri", size=13, bold=True, color="002060")
        
        ws.cell(1, 1, value="PATEL VENTURES INC").font = font_main
        ws.cell(1, 5, value="MONTHLY BALANCE SHEET").font = font_main
        ws.cell(2, 1, value="INCOME DATA").font = font_bold
        ws.cell(2, 10, value="EXPENSES DETAILS BIWEEKLY").font = font_white_bold
        for c in range(10, 13):
            ws.cell(2, c).fill = exp_hdr_fill
            
        headers = ["DATE", "DINEIN", "PICKUP", "DELIVERY", "TIP", "TOTAL", "GST", "COMMISION"]
        for idx, h in enumerate(headers, 1):
            cell = ws.cell(3, idx, value=h)
            cell.font = font_bold
            cell.fill = yellow_hdr
            cell.alignment = Alignment(horizontal="center")
            
        ws.cell(3, 10, value="AMOUNT").font = font_bold
        ws.cell(3, 11, value="DETAILS").font = font_bold
        ws.cell(3, 12, value="NARRATION").font = font_bold
        for c in range(10, 13):
            ws.cell(3, c).fill = yellow_hdr
            ws.cell(3, c).alignment = Alignment(horizontal="center")
            
        # Daily sales rows
        for i, r in enumerate(sales_records, 4):
            ws.cell(i, 1, value=r[1]).alignment = Alignment(horizontal="center")
            ws.cell(i, 2, value=r[2])
            ws.cell(i, 3, value=r[3])
            ws.cell(i, 4, value=r[4])
            ws.cell(i, 5, value=r[5])
            ws.cell(i, 6, value=f"=SUM(B{i}+C{i}+D{i}+E{i})")
            ws.cell(i, 7, value=f"=SUM(F{i}*5%)")
            ws.cell(i, 8, value=f"=SUM(D{i}*30%)")
            for c_idx in range(2, 9):
                ws.cell(i, c_idx).number_format = "$#,##0.00"
                
        # Expenses
        for j, exp in enumerate(exp_records, 4):
            ws.cell(j, 10, value=exp[2]).number_format = "$#,##0.00"
            ws.cell(j, 11, value=exp[1])
            ws.cell(j, 12, value=exp[3] or "")
            
        exp_end = 4 + len(exp_records)
        ws.cell(exp_end, 10, value=f"=SUM(J4:J{exp_end-1})").number_format = "$#,##0.00"
        ws.cell(exp_end, 10).font = font_bold
        ws.cell(exp_end, 11, value="TOTAL").font = font_bold
        for c_idx in range(10, 13):
            ws.cell(exp_end, c_idx).fill = total_fill
            
        tot_r = 4 + len(sales_records)
        ws.cell(tot_r, 1, value="TOTAL").font = font_bold
        for c_idx, ltr in enumerate(["B", "C", "D", "E", "F", "G", "H"], 2):
            ws.cell(tot_r, c_idx, value=f"=SUM({ltr}4:{ltr}{tot_r-1})")
            ws.cell(tot_r, c_idx).font = font_bold
            ws.cell(tot_r, c_idx).fill = total_fill
            ws.cell(tot_r, c_idx).number_format = "$#,##0.00"
            
        lum_r = max(tot_r - 4, exp_end + 3)
        ws.cell(lum_r, 10, value=f"=SUM(F{tot_r}-J{exp_end})").number_format = "$#,##0.00"
        ws.cell(lum_r, 10).font = font_bold
        ws.cell(lum_r, 10).fill = lumsum_fill
        ws.cell(lum_r, 11, value="LUMSUM EARNING").font = font_bold
        ws.cell(lum_r, 11).fill = lumsum_fill
        
        ws.page_setup.paperSize = ws.PAPERSIZE_A4
        ws.page_setup.orientation = ws.ORIENTATION_LANDSCAPE
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        
        buf = io.BytesIO()
        wb.save(buf)
        buf.seek(0)
        return buf
        
    excel_buf = generate_excel()
    st.download_button(
        label=f"⬇️ Download {selected_month} Excel Report",
        data=excel_buf,
        file_name=f"PATEL_VENTURES_{selected_month.replace(' ', '_')}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        type="primary"
    )
